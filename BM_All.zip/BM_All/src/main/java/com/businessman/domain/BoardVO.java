package com.businessman.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class BoardVO {
	private long bno;
	private String headers;
	private String title;
	private String content;
	private Date regdate;
	private String nick;
	
	private int replyCnt;

	private List<BoardAttachVO> attachList;
}
