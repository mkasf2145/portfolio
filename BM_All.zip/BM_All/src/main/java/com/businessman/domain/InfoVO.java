package com.businessman.domain;

import lombok.Data;

@Data
public class InfoVO {
	private String bname;
	private String kind;
	private long cost;
	private String note;

	private String blogo;
	private String type;
	private String store;
}
