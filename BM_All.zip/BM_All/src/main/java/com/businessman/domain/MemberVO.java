package com.businessman.domain;

import java.util.List;

import lombok.Data;

@Data
public class MemberVO {
	private String nick;
	private String name;
	private String email;
	private String password;
	private String groups;
	private boolean enabled;
	
	private List<AuthVO> authList;
}
