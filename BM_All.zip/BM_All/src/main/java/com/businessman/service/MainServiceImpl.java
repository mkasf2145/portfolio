package com.businessman.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.businessman.domain.CategoryVO;
import com.businessman.domain.InfoVO;
import com.businessman.domain.ListVO;
import com.businessman.mapper.MainMapper;

import lombok.Setter;

@Service
public class MainServiceImpl implements MainService {

	@Setter(onMethod_ = @Autowired)
	private MainMapper mapper;
	
	@Override
	public List<CategoryVO> listbrand(String category) {
		return mapper.listbrand(category);
	}

	@Override
	public List<ListVO> getList() {
		return mapper.getList();
	}

	@Override
	public Object listbrand() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<InfoVO> infocost(String bname){
		return mapper.infocost(bname);
	}

	@Override
	public List<InfoVO> infobrand(String bname) {
		return mapper.infobrand(bname);
	}

}
