package com.businessman.mapper;

import java.util.List;

import com.businessman.domain.CategoryVO;
import com.businessman.domain.InfoVO;
import com.businessman.domain.ListVO;

public interface MainMapper {
	public List<ListVO> getList();
	public List<CategoryVO> listbrand(String category);
	public List<InfoVO> infocost(String bname);
	public List<InfoVO> infobrand(String bname);
}
